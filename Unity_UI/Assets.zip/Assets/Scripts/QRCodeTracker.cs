using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

/// <summary>
/// AR二维码追踪器
/// 当扫描到339或108的二维码时，显示对应的公交信息UI
/// </summary>
[RequireComponent(typeof(ARTrackedImageManager))]
public class QRCodeTracker : MonoBehaviour
{
    [Header("═══════════════════════════════════════════════")]
    [Header("        AR追踪配置")]
    [Header("═══════════════════════════════════════════════")]
    
    [Tooltip("AR图像追踪管理器")]
    public ARTrackedImageManager trackedImageManager;
    
    [Tooltip("公交信息UI Canvas")]
    public GameObject transitHubUI;
    
    [Header("═══════════════════════════════════════════════")]
    [Header("        显示设置")]
    [Header("═══════════════════════════════════════════════")]
    
    [Tooltip("UI距离二维码的偏移量（米）")]
    public Vector3 uiOffset = new Vector3(0, 0, 0.1f);
    
    [Tooltip("UI缩放大小")]
    [Range(0.1f, 2f)]
    public float uiScale = 1f;
    
    [Tooltip("是否让UI始终面向摄像机")]
    public bool billboardMode = true;
    
    [Header("═══════════════════════════════════════════════")]
    [Header("        调试选项")]
    [Header("═══════════════════════════════════════════════")]
    
    [Tooltip("是否显示调试日志")]
    public bool showDebugLogs = true;
    
    [Tooltip("是否在Scene视图中显示辅助线")]
    public bool showGizmos = true;
    
    // 内部状态
    private Camera arCamera;
    private bool isUIVisible = false;
    private Transform currentTrackedImage;
    
    // ═════════════════════════════════════════════════════════════
    //                          Unity生命周期
    // ═════════════════════════════════════════════════════════════
    
    void Awake()
    {
        // 如果未手动指定，自动获取组件
        if (trackedImageManager == null)
        {
            trackedImageManager = GetComponent<ARTrackedImageManager>();
        }
        
        // 获取AR摄像机
        arCamera = Camera.main;
        
        // 初始时隐藏UI
        if (transitHubUI != null)
        {
            transitHubUI.SetActive(false);
            transitHubUI.transform.localScale = Vector3.one * uiScale;
        }
    }
    
    void OnEnable()
    {
        if (trackedImageManager != null)
        {
            // 订阅图像追踪事件
            trackedImageManager.trackedImagesChanged += OnTrackedImagesChanged;
            Log("已订阅AR图像追踪事件");
        }
        else
        {
            LogError("ARTrackedImageManager未找到！请确保组件已正确添加");
        }
    }
    
    void OnDisable()
    {
        if (trackedImageManager != null)
        {
            // 取消订阅
            trackedImageManager.trackedImagesChanged -= OnTrackedImagesChanged;
            Log("已取消订阅AR图像追踪事件");
        }
    }
    
    void Update()
    {
        // 如果UI可见且启用了Billboard模式，让UI面向摄像机
        if (isUIVisible && billboardMode && transitHubUI != null && arCamera != null)
        {
            Vector3 lookDirection = arCamera.transform.position - transitHubUI.transform.position;
            lookDirection.y = 0; // 只在水平面旋转
            
            if (lookDirection != Vector3.zero)
            {
                transitHubUI.transform.rotation = Quaternion.LookRotation(-lookDirection);
            }
        }
        
        // 如果当前有追踪的图像，更新UI位置
        if (isUIVisible && currentTrackedImage != null && transitHubUI != null)
        {
            UpdateUIPosition(currentTrackedImage);
        }
    }
    
    // ═════════════════════════════════════════════════════════════
    //                      AR图像追踪回调
    // ═════════════════════════════════════════════════════════════
    
    /// <summary>
    /// 当追踪的图像状态改变时调用
    /// </summary>
    void OnTrackedImagesChanged(ARTrackedImagesChangedEventArgs args)
    {
        // 处理新检测到的图像
        foreach (var trackedImage in args.added)
        {
            OnImageDetected(trackedImage);
        }
        
        // 处理更新的图像（位置、旋转变化）
        foreach (var trackedImage in args.updated)
        {
            OnImageUpdated(trackedImage);
        }
        
        // 处理丢失的图像
        foreach (var trackedImage in args.removed)
        {
            OnImageLost(trackedImage);
        }
    }
    
    /// <summary>
    /// 当检测到新图像时
    /// </summary>
    void OnImageDetected(ARTrackedImage trackedImage)
    {
        string imageName = trackedImage.referenceImage.name;
        Log($"检测到图像: {imageName}");
        
        // 检查是否是我们关注的二维码
        if (IsValidQRCode(imageName))
        {
            Log($"有效的二维码: {imageName}");
            ShowUI(trackedImage);
        }
    }
    
    /// <summary>
    /// 当图像位置更新时
    /// </summary>
    void OnImageUpdated(ARTrackedImage trackedImage)
    {
        string imageName = trackedImage.referenceImage.name;
        
        // 只处理我们关注的二维码
        if (!IsValidQRCode(imageName)) return;
        
        // 检查追踪状态
        if (trackedImage.trackingState == TrackingState.Tracking)
        {
            // 追踪正常，更新UI位置
            if (!isUIVisible)
            {
                ShowUI(trackedImage);
            }
            else
            {
                currentTrackedImage = trackedImage.transform;
            }
        }
        else if (trackedImage.trackingState == TrackingState.Limited)
        {
            // 追踪受限（部分遮挡或光线不足）
            Log($"图像追踪受限: {imageName}");
        }
        else if (trackedImage.trackingState == TrackingState.None)
        {
            // 丢失追踪
            Log($"丢失图像追踪: {imageName}");
            HideUI();
        }
    }
    
    /// <summary>
    /// 当图像丢失时
    /// </summary>
    void OnImageLost(ARTrackedImage trackedImage)
    {
        string imageName = trackedImage.referenceImage.name;
        Log($"图像移除: {imageName}");
        
        if (IsValidQRCode(imageName))
        {
            HideUI();
        }
    }
    
    // ═════════════════════════════════════════════════════════════
    //                         UI控制方法
    // ═════════════════════════════════════════════════════════════
    
    /// <summary>
    /// 显示UI
    /// </summary>
    void ShowUI(ARTrackedImage trackedImage)
    {
        if (transitHubUI == null)
        {
            LogError("TransitHubUI未设置！");
            return;
        }
        
        // 激活UI
        transitHubUI.SetActive(true);
        isUIVisible = true;
        currentTrackedImage = trackedImage.transform;
        
        // 设置UI位置和旋转
        UpdateUIPosition(trackedImage.transform);
        
        Log($"显示UI at {transitHubUI.transform.position}");
    }
    
    /// <summary>
    /// 隐藏UI
    /// </summary>
    void HideUI()
    {
        if (transitHubUI != null)
        {
            transitHubUI.SetActive(false);
            isUIVisible = false;
            currentTrackedImage = null;
            Log("隐藏UI");
        }
    }
    
    /// <summary>
    /// 更新UI位置
    /// </summary>
    void UpdateUIPosition(Transform imageTransform)
    {
        if (transitHubUI == null || imageTransform == null) return;
        
        // 计算UI位置（二维码位置 + 偏移）
        Vector3 targetPosition = imageTransform.position + imageTransform.TransformDirection(uiOffset);
        transitHubUI.transform.position = targetPosition;
        
        // 如果不是Billboard模式，使用二维码的旋转
        if (!billboardMode)
        {
            transitHubUI.transform.rotation = imageTransform.rotation;
        }
    }
    
    // ═════════════════════════════════════════════════════════════
    //                         辅助方法
    // ═════════════════════════════════════════════════════════════
    
    /// <summary>
    /// 检查是否是有效的二维码
    /// </summary>
    bool IsValidQRCode(string imageName)
    {
        // 检查图像名称是否包含339或108
        return imageName.Contains("339") || 
               imageName.Contains("108") || 
               imageName.Contains("QR_339") || 
               imageName.Contains("QR_108") ||
               imageName.ToLower().Contains("route339") ||
               imageName.ToLower().Contains("route108");
    }
    
    /// <summary>
    /// 日志输出
    /// </summary>
    void Log(string message)
    {
        if (showDebugLogs)
        {
            Debug.Log($"[QRCodeTracker] {message}");
        }
    }
    
    /// <summary>
    /// 错误日志输出
    /// </summary>
    void LogError(string message)
    {
        Debug.LogError($"[QRCodeTracker] {message}");
    }
    
    // ═════════════════════════════════════════════════════════════
    //                         调试辅助
    // ═════════════════════════════════════════════════════════════
    
    void OnDrawGizmos()
    {
        if (!showGizmos) return;
        
        // 如果UI可见，绘制调试信息
        if (isUIVisible && transitHubUI != null && currentTrackedImage != null)
        {
            // 绘制从二维码到UI的连线
            Gizmos.color = Color.green;
            Gizmos.DrawLine(currentTrackedImage.position, transitHubUI.transform.position);
            
            // 绘制UI位置的球体
            Gizmos.color = Color.yellow;
            Gizmos.DrawSphere(transitHubUI.transform.position, 0.05f);
            
            // 绘制二维码位置的球体
            Gizmos.color = Color.red;
            Gizmos.DrawSphere(currentTrackedImage.position, 0.03f);
        }
    }
}


// ═════════════════════════════════════════════════════════════
//                     使用说明
// ═════════════════════════════════════════════════════════════
/*

【配置步骤】

1. 在Hierarchy中找到或创建 "AR Session Origin" GameObject
2. 将此脚本挂载到 "AR Session Origin" 上
3. 在Inspector中设置：
   - Tracked Image Manager: 自动获取，或手动拖入
   - Transit Hub UI: 拖入你的公交信息UI Canvas

【创建Reference Image Library】

1. 在Project窗口右键 → Create → XR → Reference Image Library
2. 命名为 "BusQRCodes"
3. 点击 "Add Image"，添加339和108的二维码图片
4. 给每个图像命名，如：
   - "QR_339" 或 "route339"
   - "QR_108" 或 "route108"
5. 在AR Session Origin的ARTrackedImageManager组件中，
   将Reference Library字段设置为你创建的 "BusQRCodes"

【二维码图片要求】

- 格式：PNG或JPG
- 尺寸：至少512x512像素
- 清晰度：高清，无模糊
- 对比度：黑白对比明显
- 物理尺寸：在Inspector中设置实际打印尺寸（米）

【测试步骤】

1. 打印二维码（推荐A4纸大小）
2. 在Unity中运行（或打包到手机）
3. 用摄像头对准二维码
4. UI应该自动显示在二维码上方

【常见问题】

Q: 为什么扫描不到二维码？
A: 
- 检查ARTrackedImageManager是否正确配置
- 确保Reference Library包含二维码图像
- 检查光线是否充足
- 确保二维码清晰、平整

Q: UI显示位置不对？
A: 
- 调整 uiOffset 参数
- 检查 uiScale 大小
- 尝试开启/关闭 billboardMode

Q: UI总是消失？
A: 
- 保持摄像头对准二维码
- 检查追踪状态日志
- 增大二维码打印尺寸

*/