using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// UCL东校区公交&天气显示系统 - 主UI控制器
/// 负责管理所有UI元素的显示和更新
/// </summary>
public class TransitHubUI : MonoBehaviour
{
    [Header("═══════════════════════════════════════════════")]
    [Header("        公交路线339 UI组件")]
    [Header("═══════════════════════════════════════════════")]
    [Tooltip("339路公交车列表的父容器")]
    public Transform route339Container;
    
    [Header("═══════════════════════════════════════════════")]
    [Header("        公交路线108 UI组件")]
    [Header("═══════════════════════════════════════════════")]
    [Tooltip("108路公交车列表的父容器")]
    public Transform route108Container;
    
    [Header("═══════════════════════════════════════════════")]
    [Header("        公交车条目预制体")]
    [Header("═══════════════════════════════════════════════")]
    [Tooltip("公交车信息条目的预制体")]
    public GameObject busItemPrefab;
    
    [Header("═══════════════════════════════════════════════")]
    [Header("        天气显示 UI组件")]
    [Header("═══════════════════════════════════════════════")]
    [Tooltip("天气状况描述文本")]
    public TextMeshProUGUI weatherConditionText;
    
    [Tooltip("天气详细信息文本")]
    public TextMeshProUGUI weatherDetailsText;
    
    [Tooltip("天气图标")]
    public Image weatherIcon;
    
    [Tooltip("天气粒子特效容器")]
    public GameObject weatherParticleContainer;
    
    [Header("═══════════════════════════════════════════════")]
    [Header("        温度与建议 UI组件")]
    [Header("═══════════════════════════════════════════════")]
    [Tooltip("温度显示文本")]
    public TextMeshProUGUI temperatureText;
    
    [Tooltip("建议标题文本")]
    public TextMeshProUGUI suggestionTitleText;
    
    [Tooltip("建议描述文本")]
    public TextMeshProUGUI suggestionDescText;
    
    [Tooltip("建议图标")]
    public Image suggestionIcon;
    
    [Tooltip("下一班车出发时间")]
    public TextMeshProUGUI nextBusDepartureTimeText;
    
    [Tooltip("出发地点")]
    public TextMeshProUGUI nextBusDepartureFromText;
    
    [Header("═══════════════════════════════════════════════")]
    [Header("        数据可视化组件")]
    [Header("═══════════════════════════════════════════════")]
    [Tooltip("数据可视化容器")]
    public Transform dataVizContainer;
    
    [Tooltip("数据可视化柱状图数组")]
    public Image[] dataVizBars;
    
    [Header("═══════════════════════════════════════════════")]
    [Header("        天气粒子特效")]
    [Header("═══════════════════════════════════════════════")]
    [Tooltip("晴天特效")]
    public ParticleSystem sunnyEffect;
    
    [Tooltip("雨天特效")]
    public ParticleSystem rainyEffect;
    
    [Tooltip("雪天特效")]
    public ParticleSystem snowEffect;
    
    [Tooltip("多云特效")]
    public ParticleSystem cloudyEffect;
    
    // ═════════════════════════════════════════════════════════════
    //                          数据结构定义
    // ═════════════════════════════════════════════════════════════
    
    /// <summary>
    /// 公交车到站信息数据结构
    /// </summary>
    [System.Serializable]
    public class BusArrival
    {
        public string departureTime;      // 发车时间，如 "04:29"
        public string stopName;           // 站点名称，如 "UCL EAST / E"
        public int minutesUntilArrival;   // 还有几分钟到达
        public string status;             // 状态，如 "ON TIME"
    }
    
    /// <summary>
    /// 天气数据结构
    /// </summary>
    [System.Serializable]
    public class WeatherData
    {
        public string condition;          // 天气状况描述
        public float temperature;         // 温度（摄氏度）
        public float windSpeed;           // 风速（米/秒）
        public int humidity;              // 湿度（百分比）
        public float visibility;          // 可见度（公里）
        public float feelsLike;           // 体感温度
        public WeatherType weatherType;   // 天气类型枚举
    }
    
    /// <summary>
    /// 天气类型枚举
    /// </summary>
    public enum WeatherType
    {
        Sunny,      // 晴天
        Rainy,      // 雨天
        Cloudy,     // 多云
        Snowy,      // 雪天
        Windy       // 大风
    }
    
    // ═════════════════════════════════════════════════════════════
    //                          Unity生命周期
    // ═════════════════════════════════════════════════════════════
    
    void Start()
    {
        Debug.Log("TransitHubUI 初始化...");
        
        // 加载示例数据（仅用于测试，实际使用时会被API数据替换）
        LoadSampleData();
        
        Debug.Log("TransitHubUI 初始化完成");
    }
    
    // ═════════════════════════════════════════════════════════════
    //                     公开API - 供外部调用
    // ═════════════════════════════════════════════════════════════
    
    /// <summary>
    /// 加载339路公交数据
    /// 当你的API返回数据时，调用这个方法更新UI
    /// </summary>
    /// <param name="arrivals">公交到站信息列表</param>
    public void LoadRoute339Data(List<BusArrival> arrivals)
    {
        Debug.Log($"更新339路公交数据，共 {arrivals.Count} 条");
        
        // 清空旧数据
        ClearBusItems(route339Container);
        
        // 创建新的UI条目
        foreach (var arrival in arrivals)
        {
            CreateBusItem(route339Container, arrival);
        }
    }
    
    /// <summary>
    /// 加载108路公交数据
    /// 当你的API返回数据时，调用这个方法更新UI
    /// </summary>
    /// <param name="arrivals">公交到站信息列表</param>
    public void LoadRoute108Data(List<BusArrival> arrivals)
    {
        Debug.Log($"更新108路公交数据，共 {arrivals.Count} 条");
        
        // 清空旧数据
        ClearBusItems(route108Container);
        
        // 创建新的UI条目
        foreach (var arrival in arrivals)
        {
            CreateBusItem(route108Container, arrival);
        }
    }
    
    /// <summary>
    /// 更新天气数据
    /// 当你的天气API返回数据时，调用这个方法更新UI
    /// </summary>
    /// <param name="weather">天气数据</param>
    public void UpdateWeatherData(WeatherData weather)
    {
        Debug.Log($"更新天气数据：{weather.condition}, {weather.temperature}°C");
        
        // 更新天气描述
        if (weatherConditionText != null)
        {
            weatherConditionText.text = weather.condition;
        }
        
        // 更新详细信息
        if (weatherDetailsText != null)
        {
            weatherDetailsText.text = $"Wind: {weather.windSpeed} m/s • Humidity: {weather.humidity}%\n" +
                                      $"Visibility: {weather.visibility} km • Feels like: {weather.feelsLike}°C";
        }
        
        // 更新温度显示
        if (temperatureText != null)
        {
            temperatureText.text = $"{Mathf.RoundToInt(weather.temperature)}°C";
        }
        
        // 根据天气类型触发特效
        TriggerWeatherEffect(weather.weatherType);
        
        // 更新出行建议
        UpdateSuggestion(weather);
    }
    
    /// <summary>
    /// 更新下一班车出发时间
    /// 根据实时公交数据计算最佳出发时间
    /// </summary>
    /// <param name="departureTime">出发时间，如 "14:23"</param>
    /// <param name="fromLocation">出发地点</param>
    public void UpdateNextBusDeparture(string departureTime, string fromLocation)
    {
        Debug.Log($"更新出发时间：{departureTime} from {fromLocation}");
        
        if (nextBusDepartureTimeText != null)
        {
            nextBusDepartureTimeText.text = $"LEAVE BY {departureTime}";
        }
        
        if (nextBusDepartureFromText != null)
        {
            nextBusDepartureFromText.text = $"FROM: {fromLocation}";
        }
    }
    
    /// <summary>
    /// 更新数据可视化
    /// 根据统计数据更新柱状图
    /// </summary>
    /// <param name="data">数据数组，值范围0-1</param>
    public void UpdateDataVisualization(float[] data)
    {
        Debug.Log($"更新数据可视化，共 {data.Length} 个数据点");
        
        if (dataVizBars == null || dataVizBars.Length == 0)
        {
            Debug.LogWarning("数据可视化柱状图未设置");
            return;
        }
        
        for (int i = 0; i < dataVizBars.Length && i < data.Length; i++)
        {
            if (dataVizBars[i] != null)
            {
                // 更新柱状图高度
                RectTransform rt = dataVizBars[i].GetComponent<RectTransform>();
                if (rt != null)
                {
                    float targetHeight = data[i] * 200f; // 最大高度200像素
                    StartCoroutine(AnimateBarHeight(rt, targetHeight));
                }
            }
        }
    }
    
    // ═════════════════════════════════════════════════════════════
    //                         内部辅助方法
    // ═════════════════════════════════════════════════════════════
    
    /// <summary>
    /// 创建单个公交车信息条目
    /// </summary>
    void CreateBusItem(Transform container, BusArrival arrival)
    {
        if (busItemPrefab == null)
        {
            Debug.LogError("BusItemPrefab 未设置！请在Inspector中指定");
            return;
        }
        
        if (container == null)
        {
            Debug.LogError("Container 为空！");
            return;
        }
        
        // 实例化预制体
        GameObject item = Instantiate(busItemPrefab, container);
        
        // 查找并设置各个文本组件
        TextMeshProUGUI timeText = item.transform.Find("TimeText")?.GetComponent<TextMeshProUGUI>();
        TextMeshProUGUI stopText = item.transform.Find("StopText")?.GetComponent<TextMeshProUGUI>();
        TextMeshProUGUI minutesText = item.transform.Find("MinutesText")?.GetComponent<TextMeshProUGUI>();
        TextMeshProUGUI statusText = item.transform.Find("StatusText")?.GetComponent<TextMeshProUGUI>();
        
        // 赋值
        if (timeText != null) timeText.text = arrival.departureTime;
        if (stopText != null) stopText.text = $"STOP: {arrival.stopName}";
        if (minutesText != null) minutesText.text = $"{arrival.minutesUntilArrival} min";
        if (statusText != null) statusText.text = $"STATUS: {arrival.status}";
    }
    
    /// <summary>
    /// 清空容器中的所有子对象
    /// </summary>
    void ClearBusItems(Transform container)
    {
        if (container == null) return;
        
        foreach (Transform child in container)
        {
            Destroy(child.gameObject);
        }
    }
    
    /// <summary>
    /// 触发对应的天气特效
    /// </summary>
    void TriggerWeatherEffect(WeatherType weatherType)
    {
        Debug.Log($"触发天气特效：{weatherType}");
        
        // 关闭所有特效
        if (sunnyEffect != null) sunnyEffect.Stop();
        if (rainyEffect != null) rainyEffect.Stop();
        if (snowEffect != null) snowEffect.Stop();
        if (cloudyEffect != null) cloudyEffect.Stop();
        
        // 根据天气类型开启对应特效
        switch (weatherType)
        {
            case WeatherType.Sunny:
                if (sunnyEffect != null) sunnyEffect.Play();
                break;
            case WeatherType.Rainy:
                if (rainyEffect != null) rainyEffect.Play();
                break;
            case WeatherType.Snowy:
                if (snowEffect != null) snowEffect.Play();
                break;
            case WeatherType.Cloudy:
                if (cloudyEffect != null) cloudyEffect.Play();
                break;
        }
    }
    
    /// <summary>
    /// 根据天气更新出行建议
    /// </summary>
    void UpdateSuggestion(WeatherData weather)
    {
        string title = "";
        string desc = "";
        
        // 根据温度和天气状况给出建议
        if (weather.temperature < 10)
        {
            title = "Bring a coat.";
            desc = "It's cold outside.";
        }
        else if (weather.weatherType == WeatherType.Rainy)
        {
            title = "Bring an umbrella.";
            desc = "A light coat is recommended.";
        }
        else if (weather.temperature > 25)
        {
            title = "Stay hydrated.";
            desc = "It's warm outside.";
        }
        else
        {
            title = "Enjoy the weather!";
            desc = "Perfect conditions.";
        }
        
        if (suggestionTitleText != null) suggestionTitleText.text = title;
        if (suggestionDescText != null) suggestionDescText.text = desc;
    }
    
    /// <summary>
    /// 柱状图高度动画
    /// </summary>
    IEnumerator AnimateBarHeight(RectTransform bar, float targetHeight)
    {
        float currentHeight = bar.sizeDelta.y;
        float duration = 0.5f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            float newHeight = Mathf.Lerp(currentHeight, targetHeight, t);
            bar.sizeDelta = new Vector2(bar.sizeDelta.x, newHeight);
            yield return null;
        }
        
        // 确保最终值精确
        bar.sizeDelta = new Vector2(bar.sizeDelta.x, targetHeight);
    }
    
    // ═════════════════════════════════════════════════════════════
    //                      示例数据（仅供测试）
    // ═════════════════════════════════════════════════════════════
    
    /// <summary>
    /// 加载示例数据用于测试
    /// 实际使用时，这些数据会被API返回的真实数据替换
    /// </summary>
    void LoadSampleData()
    {
        Debug.Log("加载示例数据...");
        
        // 示例339路数据
        List<BusArrival> route339Sample = new List<BusArrival>
        {
            new BusArrival { departureTime = "04:29", stopName = "UCL EAST / E", minutesUntilArrival = 3, status = "ON TIME" },
            new BusArrival { departureTime = "04:32", stopName = "UCL EAST / E", minutesUntilArrival = 6, status = "ON TIME" },
            new BusArrival { departureTime = "04:35", stopName = "UCL EAST / E", minutesUntilArrival = 9, status = "ON TIME" },
            new BusArrival { departureTime = "04:38", stopName = "UCL EAST / E", minutesUntilArrival = 12, status = "ON TIME" },
            new BusArrival { departureTime = "04:41", stopName = "UCL EAST / E", minutesUntilArrival = 15, status = "DELAYED" }
        };
        LoadRoute339Data(route339Sample);
        
        // 示例108路数据
        List<BusArrival> route108Sample = new List<BusArrival>
        {
            new BusArrival { departureTime = "04:30", stopName = "UCL EAST / E", minutesUntilArrival = 4, status = "ON TIME" },
            new BusArrival { departureTime = "04:35", stopName = "UCL EAST / E", minutesUntilArrival = 9, status = "ON TIME" },
            new BusArrival { departureTime = "04:40", stopName = "UCL EAST / E", minutesUntilArrival = 14, status = "ON TIME" }
        };
        LoadRoute108Data(route108Sample);
        
        // 示例天气数据
        WeatherData weatherSample = new WeatherData
        {
            condition = "Sunny, light breeze",
            temperature = 12f,
            windSpeed = 5f,
            humidity = 55,
            visibility = 10f,
            feelsLike = 12f,
            weatherType = WeatherType.Sunny
        };
        UpdateWeatherData(weatherSample);
        
        // 示例下一班车时间
        UpdateNextBusDeparture("14:23", "UCL EAST CAMPUS MAIN ENTRANCE");
        
        // 示例数据可视化（模拟每小时乘客量）
        UpdateDataVisualization(new float[] { 0.3f, 0.5f, 0.7f, 0.9f, 0.6f, 0.4f, 0.8f });
    }
}
