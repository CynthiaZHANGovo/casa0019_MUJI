using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

/// <summary>
/// API管理器
/// 负责从远程服务器获取公交和天气数据
/// </summary>
public class APIManager : MonoBehaviour
{
    [Header("═══════════════════════════════════════════════")]
    [Header("        API配置")]
    [Header("═══════════════════════════════════════════════")]
    
    [Tooltip("公交数据API地址 - 由你的团队成员提供")]
    public string busApiUrl = "https://your-api-domain.com/api/bus";
    
    [Tooltip("天气数据API地址 - 由你的团队成员提供")]
    public string weatherApiUrl = "https://your-api-domain.com/api/weather";
    
    [Tooltip("数据更新间隔（秒）")]
    [Range(10f, 300f)]
    public float updateInterval = 30f;
    
    [Tooltip("是否启用自动更新")]
    public bool enableAutoUpdate = true;
    
    [Header("═══════════════════════════════════════════════")]
    [Header("        调试选项")]
    [Header("═══════════════════════════════════════════════")]
    
    [Tooltip("是否显示详细日志")]
    public bool showDetailedLogs = true;
    
    [Tooltip("是否使用模拟数据（当API不可用时）")]
    public bool useMockData = false;
    
    // 内部引用
    private TransitHubUI uiManager;
    private bool isUpdating = false;
    
    // ═════════════════════════════════════════════════════════════
    //                          Unity生命周期
    // ═════════════════════════════════════════════════════════════
    
    void Start()
    {
        // 获取UI管理器组件
        uiManager = GetComponent<TransitHubUI>();
        
        if (uiManager == null)
        {
            Debug.LogError("未找到TransitHubUI组件！请确保APIManager和TransitHubUI挂载在同一个GameObject上");
            return;
        }
        
        Log("APIManager 初始化完成");
        
        // 如果启用自动更新，开始定时更新
        if (enableAutoUpdate)
        {
            StartCoroutine(UpdateDataRoutine());
        }
    }
    
    // ═════════════════════════════════════════════════════════════
    //                         公开方法
    // ═════════════════════════════════════════════════════════════
    
    /// <summary>
    /// 手动触发数据更新
    /// </summary>
    public void ManualUpdate()
    {
        if (!isUpdating)
        {
            StartCoroutine(FetchAllData());
        }
        else
        {
            Debug.LogWarning("数据更新正在进行中，请稍后再试");
        }
    }
    
    // ═════════════════════════════════════════════════════════════
    //                       数据更新协程
    // ═════════════════════════════════════════════════════════════
    
    /// <summary>
    /// 定时更新数据的协程
    /// </summary>
    IEnumerator UpdateDataRoutine()
    {
        // 首次立即更新
        yield return StartCoroutine(FetchAllData());
        
        // 然后按间隔定时更新
        while (enableAutoUpdate)
        {
            yield return new WaitForSeconds(updateInterval);
            yield return StartCoroutine(FetchAllData());
        }
    }
    
    /// <summary>
    /// 获取所有数据（公交+天气）
    /// </summary>
    IEnumerator FetchAllData()
    {
        isUpdating = true;
        Log("开始更新数据...");
        
        // 并行获取公交和天气数据
        yield return StartCoroutine(FetchBusData());
        yield return StartCoroutine(FetchWeatherData());
        
        Log("数据更新完成");
        isUpdating = false;
    }
    
    // ═════════════════════════════════════════════════════════════
    //                       公交数据获取
    // ═════════════════════════════════════════════════════════════
    
    /// <summary>
    /// 获取公交数据
    /// 你的团队成员需要提供API端点，返回JSON格式的公交信息
    /// </summary>
    IEnumerator FetchBusData()
    {
        Log("正在获取公交数据...");
        
        // 如果使用模拟数据，直接返回
        if (useMockData)
        {
            Log("使用模拟公交数据");
            LoadMockBusData();
            yield break;
        }
        
        // === 获取339路数据 ===
        string route339Url = busApiUrl + "/route339";
        
        using (UnityWebRequest request = UnityWebRequest.Get(route339Url))
        {
            // 设置超时时间
            request.timeout = 10;
            
            // 发送请求
            yield return request.SendWebRequest();
            
            // 检查结果
            if (request.result == UnityWebRequest.Result.Success)
            {
                Log("339路数据获取成功");
                
                // 获取JSON响应
                string jsonResponse = request.downloadHandler.text;
                Log($"收到数据: {jsonResponse}");
                
                // 解析JSON并更新UI
                ParseAndUpdateBusData(jsonResponse, true);
            }
            else
            {
                LogError($"获取339路数据失败: {request.error}");
                LogError($"URL: {route339Url}");
                
                // 失败时使用模拟数据
                LoadMockBusData();
            }
        }
        
        // === 获取108路数据 ===
        string route108Url = busApiUrl + "/route108";
        
        using (UnityWebRequest request = UnityWebRequest.Get(route108Url))
        {
            request.timeout = 10;
            yield return request.SendWebRequest();
            
            if (request.result == UnityWebRequest.Result.Success)
            {
                Log("108路数据获取成功");
                string jsonResponse = request.downloadHandler.text;
                ParseAndUpdateBusData(jsonResponse, false);
            }
            else
            {
                LogError($"获取108路数据失败: {request.error}");
                LoadMockBusData();
            }
        }
    }
    
    /// <summary>
    /// 解析公交数据JSON并更新UI
    /// </summary>
    void ParseAndUpdateBusData(string json, bool isRoute339)
    {
        try
        {
            // 方式1: 使用JsonUtility解析（适用于简单JSON）
            // BusAPIResponse response = JsonUtility.FromJson<BusAPIResponse>(json);
            
            // 方式2: 手动解析（更灵活，适用于复杂JSON）
            // 这里提供一个示例结构，你需要根据实际API格式调整
            
            // 示例：假设API返回格式如下
            // {
            //   "route": "339",
            //   "arrivals": [
            //     {"time": "04:29", "stop": "UCL EAST / E", "eta": 3, "status": "ON TIME"},
            //     ...
            //   ]
            // }
            
            BusAPIResponse response = JsonUtility.FromJson<BusAPIResponse>(json);
            
            // 转换为UI所需格式
            List<TransitHubUI.BusArrival> arrivals = new List<TransitHubUI.BusArrival>();
            
            foreach (var item in response.arrivals)
            {
                arrivals.Add(new TransitHubUI.BusArrival
                {
                    departureTime = item.time,
                    stopName = item.stop,
                    minutesUntilArrival = item.eta,
                    status = item.status
                });
            }
            
            // 更新对应路线的UI
            if (isRoute339)
            {
                uiManager.LoadRoute339Data(arrivals);
            }
            else
            {
                uiManager.LoadRoute108Data(arrivals);
            }
            
            // 计算并更新下一班车出发时间
            if (arrivals.Count > 0)
            {
                CalculateNextDeparture(arrivals[0]);
            }
        }
        catch (Exception e)
        {
            LogError($"解析公交数据失败: {e.Message}");
            LoadMockBusData();
        }
    }
    
    // ═════════════════════════════════════════════════════════════
    //                       天气数据获取
    // ═════════════════════════════════════════════════════════════
    
    /// <summary>
    /// 获取天气数据
    /// </summary>
    IEnumerator FetchWeatherData()
    {
        Log("正在获取天气数据...");
        
        if (useMockData)
        {
            Log("使用模拟天气数据");
            LoadMockWeatherData();
            yield break;
        }
        
        using (UnityWebRequest request = UnityWebRequest.Get(weatherApiUrl))
        {
            request.timeout = 10;
            yield return request.SendWebRequest();
            
            if (request.result == UnityWebRequest.Result.Success)
            {
                Log("天气数据获取成功");
                string jsonResponse = request.downloadHandler.text;
                Log($"收到数据: {jsonResponse}");
                
                ParseAndUpdateWeatherData(jsonResponse);
            }
            else
            {
                LogError($"获取天气数据失败: {request.error}");
                LogError($"URL: {weatherApiUrl}");
                LoadMockWeatherData();
            }
        }
    }
    
    /// <summary>
    /// 解析天气数据JSON并更新UI
    /// </summary>
    void ParseAndUpdateWeatherData(string json)
    {
        try
        {
            // 假设API返回格式如下
            // {
            //   "condition": "Sunny, light breeze",
            //   "temperature": 12,
            //   "windSpeed": 5,
            //   "humidity": 55,
            //   "visibility": 10,
            //   "feelsLike": 12,
            //   "weatherType": "Sunny"
            // }
            
            WeatherAPIResponse response = JsonUtility.FromJson<WeatherAPIResponse>(json);
            
            // 转换为UI所需格式
            TransitHubUI.WeatherData weather = new TransitHubUI.WeatherData
            {
                condition = response.condition,
                temperature = response.temperature,
                windSpeed = response.windSpeed,
                humidity = response.humidity,
                visibility = response.visibility,
                feelsLike = response.feelsLike,
                weatherType = ParseWeatherType(response.weatherType)
            };
            
            uiManager.UpdateWeatherData(weather);
        }
        catch (Exception e)
        {
            LogError($"解析天气数据失败: {e.Message}");
            LoadMockWeatherData();
        }
    }
    
    // ═════════════════════════════════════════════════════════════
    //                         辅助方法
    // ═════════════════════════════════════════════════════════════
    
    /// <summary>
    /// 计算下一班车的最佳出发时间
    /// </summary>
    void CalculateNextDeparture(TransitHubUI.BusArrival nextBus)
    {
        // 假设从学校到站点需要5分钟步行时间
        int walkingTime = 5;
        int bufferTime = 2; // 缓冲时间
        
        int minutesToLeave = nextBus.minutesUntilArrival - walkingTime - bufferTime;
        
        if (minutesToLeave < 0) minutesToLeave = 0;
        
        // 计算出发时间
        DateTime now = DateTime.Now;
        DateTime departureTime = now.AddMinutes(minutesToLeave);
        
        string timeString = departureTime.ToString("HH:mm");
        
        uiManager.UpdateNextBusDeparture(timeString, "UCL EAST CAMPUS MAIN ENTRANCE");
    }
    
    /// <summary>
    /// 将字符串转换为天气类型枚举
    /// </summary>
    TransitHubUI.WeatherType ParseWeatherType(string typeString)
    {
        try
        {
            return (TransitHubUI.WeatherType)Enum.Parse(typeof(TransitHubUI.WeatherType), typeString);
        }
        catch
        {
            return TransitHubUI.WeatherType.Sunny; // 默认值
        }
    }
    
    /// <summary>
    /// 加载模拟公交数据（用于测试）
    /// </summary>
    void LoadMockBusData()
    {
        Log("使用模拟公交数据");
        // TransitHubUI.Start() 已经加载了示例数据，这里不需要重复
    }
    
    /// <summary>
    /// 加载模拟天气数据（用于测试）
    /// </summary>
    void LoadMockWeatherData()
    {
        Log("使用模拟天气数据");
        // TransitHubUI.Start() 已经加载了示例数据
    }
    
    /// <summary>
    /// 日志输出（带开关控制）
    /// </summary>
    void Log(string message)
    {
        if (showDetailedLogs)
        {
            Debug.Log($"[APIManager] {message}");
        }
    }
    
    /// <summary>
    /// 错误日志输出
    /// </summary>
    void LogError(string message)
    {
        Debug.LogError($"[APIManager] {message}");
    }
    
    // ═════════════════════════════════════════════════════════════
    //                    API响应数据结构
    // ═════════════════════════════════════════════════════════════
    
    /// <summary>
    /// 公交API响应数据结构
    /// 注意：这个结构需要与你的实际API返回格式完全匹配
    /// </summary>
    [System.Serializable]
    public class BusAPIResponse
    {
        public string route;
        public BusAPIItem[] arrivals;
    }
    
    [System.Serializable]
    public class BusAPIItem
    {
        public string time;      // 发车时间
        public string stop;      // 站点名称
        public int eta;          // 到达时间（分钟）
        public string status;    // 状态
    }
    
    /// <summary>
    /// 天气API响应数据结构
    /// 注意：这个结构需要与你的实际API返回格式完全匹配
    /// </summary>
    [System.Serializable]
    public class WeatherAPIResponse
    {
        public string condition;
        public float temperature;
        public float windSpeed;
        public int humidity;
        public float visibility;
        public float feelsLike;
        public string weatherType;
    }
}


// ═════════════════════════════════════════════════════════════
//                     使用说明和注意事项
// ═════════════════════════════════════════════════════════════
/*

【给你的团队成员的API格式要求】

1. 公交数据API应该返回以下JSON格式：
   
   GET https://your-api-domain.com/api/bus/route339
   
   响应：
   {
     "route": "339",
     "arrivals": [
       {
         "time": "04:29",
         "stop": "UCL EAST / E",
         "eta": 3,
         "status": "ON TIME"
       },
       {
         "time": "04:32",
         "stop": "UCL EAST / E",
         "eta": 6,
         "status": "ON TIME"
       }
     ]
   }

2. 天气数据API应该返回以下JSON格式：
   
   GET https://your-api-domain.com/api/weather
   
   响应：
   {
     "condition": "Sunny, light breeze",
     "temperature": 12,
     "windSpeed": 5,
     "humidity": 55,
     "visibility": 10,
     "feelsLike": 12,
     "weatherType": "Sunny"
   }
   
   weatherType 可选值: "Sunny", "Rainy", "Cloudy", "Snowy", "Windy"

3. 如果你的API格式不同，需要修改：
   - BusAPIResponse 和 BusAPIItem 类的字段
   - WeatherAPIResponse 类的字段
   - ParseAndUpdateBusData() 方法中的解析逻辑
   - ParseAndUpdateWeatherData() 方法中的解析逻辑

【配置步骤】

1. 在Unity中，选中挂载了APIManager的GameObject
2. 在Inspector中填写：
   - Bus Api Url: 你的公交数据API地址
   - Weather Api Url: 你的天气数据API地址
   - Update Interval: 数据更新间隔（秒）
3. 勾选 "Use Mock Data" 可以在API不可用时使用模拟数据测试
4. 勾选 "Show Detailed Logs" 可以看到详细的调试信息

【测试步骤】

1. 先勾选 "Use Mock Data" 测试UI是否正常工作
2. 确认UI正常后，取消勾选，填入实际API地址
3. 运行游戏，检查Console中的日志信息
4. 如果看到 "数据获取成功"，说明API连接正常
5. 如果看到错误信息，检查API地址和网络连接

*/